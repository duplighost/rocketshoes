// The single state object + save plumbing + run creation.
import { SAVE_KEY, LEGACY_SAVE_KEYS, VERSION } from './config.js';
import { hashString, mulberry32 } from './rng.js';

function defaultSave() {
  return {
    version: VERSION, bestScore: 0, bestRound: 0, runs: 0, sparks: 0,
    settings: { sfx: true, bgm: true },
    bestiary: {}, notices: [], seenItems: {}, shrine: {}, unlocks: { victoryShirt: false },
    firstWinAt: null, lastWin: null,
    lifetime: { kills: 0, rooms: 0, deaths: 0, wins: 0, timePlayed: 0 },
  };
}

const storage = (typeof localStorage !== 'undefined') ? localStorage : {
  _m: new Map(), getItem(k) { return this._m.get(k) ?? null; },
  setItem(k, v) { this._m.set(k, String(v)); }, removeItem(k) { this._m.delete(k); },
};

export function loadSave() {
  const defaults = defaultSave();
  try {
    if (typeof location !== 'undefined' && /[?&]fresh=1/.test(location.search)) {
      storage.removeItem(SAVE_KEY);
      for (const key of LEGACY_SAVE_KEYS || []) storage.removeItem(key);
    }
    let raw = null;
    for (const key of [SAVE_KEY, ...(LEGACY_SAVE_KEYS || [])]) {
      const txt = storage.getItem(key);
      if (!txt) continue;
      try { raw = JSON.parse(txt); break; } catch { /* ignore corrupt legacy slot */ }
    }
    raw = raw || {};
    const save = Object.assign(defaults, raw, { version: VERSION });
    save.settings = Object.assign({}, defaults.settings, raw.settings || {});
    save.lifetime = Object.assign({}, defaults.lifetime, raw.lifetime || {});
    save.unlocks = Object.assign({}, defaults.unlocks, raw.unlocks || {});
    save.bestiary = Object.assign({}, defaults.bestiary, raw.bestiary || {});
    save.seenItems = Object.assign({}, defaults.seenItems, raw.seenItems || {});
    save.shrine = Object.assign({}, defaults.shrine, raw.shrine || {});
    save.notices = Array.isArray(raw.notices) ? raw.notices : defaults.notices;
    return save;
  } catch { return defaults; }
}

export function saveNow() {
  try { state.save.version = VERSION; storage.setItem(SAVE_KEY, JSON.stringify(state.save)); } catch { /* private mode */ }
}

export const state = {
  mode: 'title', // title | play | transition | portalDraft | pause | dead
  save: loadSave(),
  run: null,
  room: null,
  transition: null,        // {timer, duration, title, sub, tag, swapped, onSwap}
  fx: { shake: 0, flash: 0, slowMo: 0, hitPause: 0 },
  frameTimes: [],          // ring buffer for selfTest
  lowFx: false,            // adaptive quality: set when frames stay slow; drops bloom + halves particles
  oldMode: 'title',
};

export function newRun(seedText = Date.now()) {
  const seed = hashString(String(seedText) + '|rocketshoes');
  state.run = {
    seed, seedText: String(seedText), rng: mulberry32(seed),
    round: 0, score: 0, combo: 1, comboT: 0,
    kills: 0, roomKills: 0, streak: 0, streakT: 0,
    overdrive: false, won: false,
    startedAt: Date.now(), bags: {},
    player: null,            // set by player.makePlayer via rooms.startRun
    flags: {},               // one-shot behavior notice latches
  };
  state.save.runs = (state.save.runs || 0) + 1;
  return state.run;
}

export function bankBests() {
  const run = state.run;
  if (!run) return;
  state.save.bestScore = Math.max(state.save.bestScore || 0, Math.floor(run.score));
  state.save.bestRound = Math.max(state.save.bestRound || 0, run.round);
  saveNow();
}
